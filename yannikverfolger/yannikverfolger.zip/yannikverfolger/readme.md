## install instruction

download yannikverfolger.zip from https://github.com/horstjens/spielend-programmieren/tree/master/yannikverfolger

extract the zip on your harddisk

## install python3 and pygame

  * for linux:
    sudo apt-get install python3
    pygame instructions for pyhon3: see http://askubuntu.com/questions/401342/how-to-download-pygame-in-python3-3
  
  * for windows:
    download python3.2 the 32 bit version (yes, even if you have a 64 bit windows)! do NOT downlaod the 64 bit version from https://www.python.org/download/releases/3.2/
    download pygame "pygame-1.9.2a0.win32-py3.2.msi" for python3 from http://www.pygame.org/download.shtml
    install python3.2
    install pygame
    
## run the game

linux:
python3 yannik_verfolger.py

windows:
open yannik_verfolger.py with idle (idle is installed together with python)
press F5 or choose in the menu run -> run module
